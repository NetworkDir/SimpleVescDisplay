#ifndef CH_H
#define CH_H

typedef int systime_t;
typedef struct  {
   uint32_t *p_stklimit;
} thread_t;
#endif  // CH_H
